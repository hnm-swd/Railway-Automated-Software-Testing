package Constant;

import org.openqa.selenium.WebDriver;

public class Constant {
    public static WebDriver WEBDRIVER;
    public static final String RAILWAY_URL = "http://railwayb2.somee.com";
    public static final String USERNAME = "nhom03testng@gmail.com";
    public static final String PASSWORD = "12345678910";
//    public static final String PASSWORD = "Diemne00000";

//    public static final String USERNAME = "diem1111@gmail.com";
//    public static final String PASSWORD = "diem9999999999";

//    public static final String CONFIRMPASSWORD = "diem9999999999";
//
//    public static final String PID = "123456789";


}
